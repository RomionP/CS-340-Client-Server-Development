from pymongo import MongoClient 
from bson.objectid import ObjectId 

class AnimalShelter(object): 
    """ CRUD operations for Animal collection in MongoDB """ 

    def __init__(self, username, password): 
        # Initializing the MongoClient. This helps to access the MongoDB 
        # databases and collections. This is hard-wired to use the aac 
        # database, the animals collection, and the aac user. 
        # 
        # You must edit the password below for your environment. 
        # 
        # Connection Variables 
        # 
        USER = 'aacuser' 
        PASS = 'SNHU1234' 
        HOST = 'localhost' 
        PORT = 27017 
        DB = 'aac' 
        COL = 'animals' 
        # 
        # Initialize Connection 
        # 
        self.client = MongoClient('mongodb://%s:%s@%s:%d' % (USER,PASS,HOST,PORT)) 
        self.database = self.client['%s' % (DB)] 
        self.collection = self.database['%s' % (COL)] 

    # Create a method to return the next available record number for use in the create method
            
    # Complete this create method to implement the C in CRUD. 
    def create(self, data):
        if data is not None:
            try:
                # Insert the dictionary into the collection
                self.collection.insert_one(data)
                return True
            except Exception as e:
                print(f"An error occurred during insertion: {e}")
                return False
        else:
            raise Exception("Nothing to save, because data parameter is empty")

    # Create method to implement the R in CRUD.
    def read(self, query=None):
        """ Method to implement the R in CRUD (Read) """
        try:
            # If no query is passed, default to an empty dictionary to return all records
            if query is None:
                query = {}
            
            # Find documents matching the query and display in list
            cursor = self.collection.find(query)
            return list(cursor)
        except Exception as e:
            print(f"An error occurred during read query: {e}")
            return []
            
        # Create method to implement the U in CRUD.
    def update(self, query, update_data):
        if query is None:
            raise Exception("Nothing to update, because query parameter is empty")
        try:
            result = self.collection.update_many(query, update_data)
            return result.modified_count
        except Exception as e:
            print(f"An error occurred during update: {e}")
            return 0
        
    # Create method to implement the D in CRUD.
    def delete(self, query):
        if query is None:
            raise Exception("Nothing to delete, because query parameter is empty")
        try:
            result = self.collection.delete_many(query)
            return result.deleted_count
        except Exception as e:
            print(f"An error occurred during delete: {e}")
            return 0